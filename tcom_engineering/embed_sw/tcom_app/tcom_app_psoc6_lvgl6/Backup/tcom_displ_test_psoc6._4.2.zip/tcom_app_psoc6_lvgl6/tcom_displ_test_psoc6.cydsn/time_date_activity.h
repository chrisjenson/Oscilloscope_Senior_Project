void date_activity_action(lv_obj_t *obj, lv_event_t event);
void time_activity_action(lv_obj_t *obj, lv_event_t event);
void update_time_task(lv_task_t * task);

void set_label_dat(lv_obj_t *obj);
void set_label_tim(lv_obj_t *obj);
