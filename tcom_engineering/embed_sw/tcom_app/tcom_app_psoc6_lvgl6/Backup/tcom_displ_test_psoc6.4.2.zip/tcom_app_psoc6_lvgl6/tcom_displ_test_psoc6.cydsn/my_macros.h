#define BYTE_HI( x )        ( ((x) >> 8) & 0xFF )
#define BYTE_LO( x )        ( ((x) >> 0) & 0xFF )

