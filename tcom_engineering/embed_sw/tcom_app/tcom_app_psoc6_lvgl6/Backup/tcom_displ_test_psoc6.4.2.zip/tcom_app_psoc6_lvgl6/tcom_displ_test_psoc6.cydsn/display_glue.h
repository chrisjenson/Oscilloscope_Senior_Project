void ili9488_init();

void my_flush_cb(struct _disp_drv_t * disp_drv, const lv_area_t * area, lv_color_t * color_p);
